LAUREN’S CLAY CREATIONS — UPDATED WEBSITE FILES

This package includes the updated website and the images folder.

Included updates:
- Cream/ivory homepage background with a more mature, colorful design.
- Updated tagline: “Small details. Made to stand out.”
- Square-style brand artwork.
- Clickable lighter-case photos showing front and back.
- Coraline Keychain — $15.
- Spider-Man Keychain — $18.
- Rey Mysterio Lighter Case — $25.
- Junk Hair Clips — $5.
- Jewelry Trays placeholder — TBD.
- Updated About section photo.
- Black product-photo backgrounds retained.

PUBLISHING ON GITHUB PAGES
1. Open the GitHub repository that publishes your site.
2. Upload/replace index.html and the entire images folder from this package.
3. Keep the folder named “images” and all image filenames unchanged.
4. Commit the changes to the branch configured for GitHub Pages.
5. Wait a few minutes and refresh the live website.

IMPORTANT
- This package does not publish itself; the files must be uploaded to GitHub to change the live site.
- The order form opens an Instagram message draft; it does not process payments or confirm orders.
- Reviews/order counts are stored only in the visitor’s own browser, not in a shared database. Supabase still needs to be connected for shared data.
- The Etsy/TikTok links were not added because their exact profile URLs were not confirmed.
